package cn.sm1234;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SubmitFormServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			request.setCharacterEncoding("utf-8");
			System.out.println(request.getParameter("name"));
			System.out.println(request.getParameter("email"));
			System.out.println(request.getParameter("theme"));
			System.out.println(request.getParameter("gender"));
			
			//模拟异常
			int i = 100/0;
			
			response.getWriter().write("{\"success\":true}");
		} catch (Exception e) {
			e.printStackTrace();
			response.getWriter().write("{\"success\":false}");
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
