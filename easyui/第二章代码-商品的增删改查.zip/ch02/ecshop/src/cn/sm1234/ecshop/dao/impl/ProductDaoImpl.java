package cn.sm1234.ecshop.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import cn.sm1234.ecshop.dao.ProductDao;
import cn.sm1234.ecshop.domain.Product;
import cn.sm1234.ecshop.utils.HibernateUtils;

public class ProductDaoImpl implements ProductDao {

	@Override
	public Long findByTotalCount() {
		// 获取Session
		Session session = HibernateUtils.getSession();
		try {
			Query query = session.createQuery("select count(1) from Product");
			return (Long) query.uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			// 释放session
			session.close();
		}
	}

	@Override
	public List<Product> findByPage(Integer page, Integer rows) {
		// 获取Session
		Session session = HibernateUtils.getSession();
		try {
			Query query = session.createQuery("from Product");
			// 设置起始行
			query.setFirstResult((page - 1) * rows); // (当前页码-1)*页面大小
			// 设置页面大小
			query.setMaxResults(rows);
			return query.list();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			// 释放session
			session.close();
		}
	}

	public static void main(String[] args) {
		ProductDaoImpl dao = new ProductDaoImpl();
		// System.out.println(dao.findByTotalCount());

		List<Product> list = dao.findByPage(1, 5);
		for (Product product : list) {
			System.out.println(product.getName());
		}
	}

	@Override
	public void save(Product p) {
		// 获取Session
		Session session = HibernateUtils.getSession();
		try {
			// 打开事务
			session.beginTransaction();

			session.saveOrUpdate(p);

			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
			throw new RuntimeException(e);
		} finally {
			// 释放session
			session.close();
		}
	}

	@Override
	public Product findById(Integer id) {
		// 获取Session
		Session session = HibernateUtils.getSession();
		try {
			return session.get(Product.class, id);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			// 释放session
			session.close();
		}
	}

	@Override
	public void delete(int id) {
		// 获取Session
		Session session = HibernateUtils.getSession();
		try {
			// 打开事务
			session.beginTransaction();

			Product prod = session.get(Product.class, id);
			session.delete(prod);
			
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
			throw new RuntimeException(e);
		} finally {
			// 释放session
			session.close();
		}
	}
}
